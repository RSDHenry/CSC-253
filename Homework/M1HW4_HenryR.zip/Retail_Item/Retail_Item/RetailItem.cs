﻿/**
* 6 September 2018
* CSC 253
* Rashad Henry
* Program demonstrating using a class and form load event to
* display retail items, number of units, and prices for each.
* This program does not accept user input.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Retail_Item
{
    class RetailItem
    {
        // Properties declaration
        public string Description;
        public int UnitsOnHand;
        public double Price;

        // Create constructor and accept arguments for each property
        public RetailItem(string description, int unitsOnHand, double price)
        {
            // Define the object properties
            Description = description;
            UnitsOnHand = unitsOnHand;
            Price = price;
        }
    }
}
