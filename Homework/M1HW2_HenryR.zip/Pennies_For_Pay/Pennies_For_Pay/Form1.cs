﻿/**
* 31 Aug 2018
* CSC 253
* Rashad Henry
* A windows form that uses a listbox to calculate and display the amount of pay
* earned in pennies to the user 
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pennies_For_Pay
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {

                // Variable declarations
                int numOfDays = 0;
                int count = 1;
                double penniesCount = 1;
                double totalPennies = 0;

                // Accept number of days worked from user and convert input string to an int
                numOfDays = Convert.ToInt32(numOfDaysWrkTxtBox.Text);

                // Make sure the List Box is clear 
                penniesListBox.Items.Clear();

                // While loopp to iterate the count variable of 1 to the input accepted from numOfDays
                while (count <= numOfDays)
                {
                    // Calculate the total pennies
                    totalPennies += penniesCount;

                    // Add each corresponding day to the list box
                    penniesListBox.Items.Add("Day " + count.ToString() + ": Earned " + penniesCount.ToString() + " pennies.");

                    // Double the amount of pennies counted for each day
                    penniesCount *= 2;

                    // Increment the count
                    count++;
                }

                // Display the total amount of pay earned in pennies to the user
                totalPenniesTxtBox.Text = totalPennies.ToString();
            }
            catch
            {
                // Display an error message
                MessageBox.Show("Invalid data was entered. Please try again.");
            }
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            // Clear the form
            numOfDaysWrkTxtBox.Text = "";
            penniesListBox.Items.Clear();
            totalPenniesTxtBox.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exit the program
            this.Close();
        }
    }
}