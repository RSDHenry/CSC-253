﻿namespace Pennies_For_Pay
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.penniesListBox = new System.Windows.Forms.ListBox();
            this.numOfDaysWrkTxtBox = new System.Windows.Forms.TextBox();
            this.numOfDaysWrkLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.totalPenniesTxtBox = new System.Windows.Forms.TextBox();
            this.totalPenniesLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // penniesListBox
            // 
            this.penniesListBox.FormattingEnabled = true;
            this.penniesListBox.Location = new System.Drawing.Point(12, 71);
            this.penniesListBox.Name = "penniesListBox";
            this.penniesListBox.Size = new System.Drawing.Size(361, 238);
            this.penniesListBox.TabIndex = 0;
            // 
            // numOfDaysWrkTxtBox
            // 
            this.numOfDaysWrkTxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numOfDaysWrkTxtBox.Location = new System.Drawing.Point(250, 33);
            this.numOfDaysWrkTxtBox.Name = "numOfDaysWrkTxtBox";
            this.numOfDaysWrkTxtBox.Size = new System.Drawing.Size(100, 22);
            this.numOfDaysWrkTxtBox.TabIndex = 1;
            // 
            // numOfDaysWrkLabel
            // 
            this.numOfDaysWrkLabel.AutoSize = true;
            this.numOfDaysWrkLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numOfDaysWrkLabel.Location = new System.Drawing.Point(39, 33);
            this.numOfDaysWrkLabel.Name = "numOfDaysWrkLabel";
            this.numOfDaysWrkLabel.Size = new System.Drawing.Size(205, 16);
            this.numOfDaysWrkLabel.TabIndex = 2;
            this.numOfDaysWrkLabel.Text = "Enter the number of days worked:";
            // 
            // calculateButton
            // 
            this.calculateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateButton.Location = new System.Drawing.Point(73, 382);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 3;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetButton.Location = new System.Drawing.Point(154, 382);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 4;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(235, 382);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // totalPenniesTxtBox
            // 
            this.totalPenniesTxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalPenniesTxtBox.Location = new System.Drawing.Point(250, 331);
            this.totalPenniesTxtBox.Name = "totalPenniesTxtBox";
            this.totalPenniesTxtBox.Size = new System.Drawing.Size(100, 22);
            this.totalPenniesTxtBox.TabIndex = 6;
            // 
            // totalPenniesLabel
            // 
            this.totalPenniesLabel.AutoSize = true;
            this.totalPenniesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalPenniesLabel.Location = new System.Drawing.Point(30, 334);
            this.totalPenniesLabel.Name = "totalPenniesLabel";
            this.totalPenniesLabel.Size = new System.Drawing.Size(214, 16);
            this.totalPenniesLabel.TabIndex = 7;
            this.totalPenniesLabel.Text = "Total amount of pay (in pennies) is:";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(385, 417);
            this.Controls.Add(this.totalPenniesLabel);
            this.Controls.Add(this.totalPenniesTxtBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.numOfDaysWrkLabel);
            this.Controls.Add(this.numOfDaysWrkTxtBox);
            this.Controls.Add(this.penniesListBox);
            this.Name = "MainForm";
            this.Text = "Pennies For Pay Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox penniesListBox;
        private System.Windows.Forms.TextBox numOfDaysWrkTxtBox;
        private System.Windows.Forms.Label numOfDaysWrkLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox totalPenniesTxtBox;
        private System.Windows.Forms.Label totalPenniesLabel;
    }
}

