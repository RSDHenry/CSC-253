﻿/**
* 29 September 2018
* CSC 253
* Rashad Henry
* Using the StreamReader class to load data from text files
* into a listbox and display the number of championships
* a selected team has won
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace World_Series_Champions
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        // Array to hold the name of the World Series winners of each year
        string[] winners = new string[120];

        // Variable to the increase the while loop for each iteration
        int i = 0;

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
                // Load event and create an object of StreamReader to read the contents of Team.txt
                StreamReader inputFile = new StreamReader("Teams.txt");

                // Create a new object of StreamReader to read the contents of WorldSeriesWinners.txt
                StreamReader inputFile2 = new StreamReader("WorldSeriesWinners.txt");

                // Variable to read the contents from the text files and assign to ListBox
                string readFileWinners;

                // While loop to read the team names from Teams.txt
                while ((readFileWinners = inputFile.ReadLine()) != null)
                {
                    // Add each team in the Teams.txt to the teamsListBox
                    teamsListBox.Items.Add(readFileWinners);
                }

                // While loop to read the winning team of the World Series each year
                while ((winners[i] = inputFile2.ReadLine()) != null)
                    i++;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void teamsListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                // Get the user selected value from the ListBox from the variable inputFile (Name of team)
                string winningTeam = teamsListBox.SelectedItem.ToString();

                // Variable to use for while loop interation
                int j = 0;

                // Counter variable to keep count of the number of times a selected team won the World Series
                int count = 0;

                // While loop to being the count of number of championships of the selected team
                while (j <= i)
                {
                    // Verify if the selected team is equal to iterationB
                    if (winners[j] == winningTeam)
                        // Increase the count by 1
                        count++;
                        // Increase the value of iterationB by 1
                        j++;
                }

                // Display the selected winner and number of championships for selected team to the user
                MessageBox.Show("The " + winningTeam + " have won " + count + " World Series titles.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }
    }
}
