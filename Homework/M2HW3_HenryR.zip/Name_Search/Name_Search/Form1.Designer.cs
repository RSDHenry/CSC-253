﻿namespace Name_Search
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enterBoyNameLbl = new System.Windows.Forms.Label();
            this.enterGirlNameLbl = new System.Windows.Forms.Label();
            this.boyNameTxtBox = new System.Windows.Forms.TextBox();
            this.girlNameTxtBox = new System.Windows.Forms.TextBox();
            this.searchButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // enterBoyNameLbl
            // 
            this.enterBoyNameLbl.AutoSize = true;
            this.enterBoyNameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterBoyNameLbl.Location = new System.Drawing.Point(37, 33);
            this.enterBoyNameLbl.Name = "enterBoyNameLbl";
            this.enterBoyNameLbl.Size = new System.Drawing.Size(109, 16);
            this.enterBoyNameLbl.TabIndex = 0;
            this.enterBoyNameLbl.Text = "Enter Boy Name:";
            // 
            // enterGirlNameLbl
            // 
            this.enterGirlNameLbl.AutoSize = true;
            this.enterGirlNameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterGirlNameLbl.Location = new System.Drawing.Point(37, 86);
            this.enterGirlNameLbl.Name = "enterGirlNameLbl";
            this.enterGirlNameLbl.Size = new System.Drawing.Size(105, 16);
            this.enterGirlNameLbl.TabIndex = 1;
            this.enterGirlNameLbl.Text = "Enter Girl Name:";
            // 
            // boyNameTxtBox
            // 
            this.boyNameTxtBox.Location = new System.Drawing.Point(148, 33);
            this.boyNameTxtBox.Name = "boyNameTxtBox";
            this.boyNameTxtBox.Size = new System.Drawing.Size(235, 20);
            this.boyNameTxtBox.TabIndex = 2;
            // 
            // girlNameTxtBox
            // 
            this.girlNameTxtBox.Location = new System.Drawing.Point(148, 86);
            this.girlNameTxtBox.Name = "girlNameTxtBox";
            this.girlNameTxtBox.Size = new System.Drawing.Size(235, 20);
            this.girlNameTxtBox.TabIndex = 3;
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(151, 143);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(110, 28);
            this.searchButton.TabIndex = 4;
            this.searchButton.Text = "Search Name(s)";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(276, 143);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(110, 28);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 209);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.girlNameTxtBox);
            this.Controls.Add(this.boyNameTxtBox);
            this.Controls.Add(this.enterGirlNameLbl);
            this.Controls.Add(this.enterBoyNameLbl);
            this.Name = "MainForm";
            this.Text = "Most Popular Names Search 2000-2009";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label enterBoyNameLbl;
        private System.Windows.Forms.Label enterGirlNameLbl;
        private System.Windows.Forms.TextBox boyNameTxtBox;
        private System.Windows.Forms.TextBox girlNameTxtBox;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.Button exitButton;
    }
}

