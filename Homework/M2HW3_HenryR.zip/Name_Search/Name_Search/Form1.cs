﻿/**
* 29 September 2018
* CSC 253
* Rashad Henry
* Using two files of popular baby names this program
* Allows the user to enter in a name(s) to see if the 
* Entered name is among the popular names in the files
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Name_Search
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        // Create an arrary to hold the boy names from the BoyNames.txt file
        string[] boyNames = new string[200];

        // Create an array to hold the girl names from the GirlNames.txt file
        string[] girlNames = new string[200];

        // Declare variable to use for loop iteration
        int i = 0;

        // Using a ReadNamesIntoArray method to read the names from the text file into the names array
        private string[] ReadNamesIntoArray(string fileName)
        {
            // New array to hold the names read from the file
            string[] names = new string[200];

            // loop iteration variable
            i = 0;

            // Open a new fileName file with StreamReader object
            StreamReader inputFile = File.OpenText(fileName);

            // While loop to read to the end of the file and add names to the names array
            while (!inputFile.EndOfStream)
            {
                names[i] = inputFile.ReadLine();
                i++;
            }

            // Close the file
            inputFile.Close();

            // Return the names array
            return names;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Form load event to populate the boysName and girlsName arrays
            boyNames = ReadNamesIntoArray("BoyNames.txt");
            girlNames = ReadNamesIntoArray("GirlNames.txt");
        }

        // Create a SearchName method to search for the name in the nameList. 
        // Return true if the name is found
        private Boolean SearchName (string name, string[]namesList)
        {
            // For loop to search through each name in the nameList
            for (int i = 0; i < namesList.Count(); i++)
            {
                // If there is match in the nameList at index then return true
                if (namesList[i] == name)
                    return true;
            }
            // if no match return false
            return false;
        }

        // Create a GetResults method to update the string that will display the output
        private string GetResults (string name, Boolean isFound)
        {
            // Declare an empty string
            string result = "";

            // if isFound is true then update the string with the name and is found
            if (isFound)
            {
                // Display that the name was found
                result = "The name " + name + " is on the most popular names list!";
            }

            // If name was not found on the list then display result that name was not found
            else
            {
                result = "The name " + name + " is not on the most popular names list!";
            }

            // return the result string
            return result;
        }

        // Create a ClearTextBoxes method to clear the user input and give focus to the first text box
        private void ClearTextBoxes()
        {
            // Clear the boyNameTxtBox
            boyNameTxtBox.Clear();
            // Clear the girlNameTxtBox
            girlNameTxtBox.Clear();
            // Give focus to boyNameTxtBox
            boyNameTxtBox.Focus();
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            // Empty string variable to hold the boy name from boyNameTxtBox
            string boyName = "";
            // Empty string variable to hold the girl name from the girlNameTxtBox
            string girlName = "";
            // Empty string variable to hold the final result of the search
            string searchResult = "";

            // Boolean variable to hold the status of the boy name result 
            bool boyNamesSearch = false;
            // Boolean variable to hold the status of the girl name result
            bool girlNamesSearch = false;

            // Verify that the boyNameTxtBox and girlNameTxtBox are not empty
            if (boyNameTxtBox.Text != "" && girlNameTxtBox.Text != "")
            {
                // Place the value in the boyNameTxtBox into boyName
                boyName = boyNameTxtBox.Text;
                // Place the value in the girlNameTxtBox into girlName
                girlName = girlNameTxtBox.Text;

                // Call the SearchName method 
                boyNamesSearch = SearchName(boyName, boyNames);
                // Call the SearchName method again for the girl names
                girlNamesSearch = SearchName(girlName, girlNames);

                // Get the result of the search for the boy name and update the string
                searchResult = GetResults(boyName, boyNamesSearch);
                searchResult += "\n";

                // Get the result of the search for the girl name and update the string
                searchResult += GetResults(girlName, girlNamesSearch);
            }
            // If user only searched for a boy name then update the searchResult string and isFound status
            else if (boyNameTxtBox.Text != "")
            {
                // Store the value in the boyNameTxtBox into the boyName variable
                boyName = boyNameTxtBox.Text;

                // Take the result of the boy name search and update the string
                boyNamesSearch = SearchName(boyName, boyNames);
                searchResult = GetResults(boyName, boyNamesSearch);
            }
            // If user only search for a girl name then update the searchResult string and isFound status
            else if (girlNameTxtBox.Text != "")
            {
                // Store the value in the girlNameTxtBox into the girlName variable
                girlName = girlNameTxtBox.Text;

                // Take the result of the girl name search and update the string from calling the SearchName method
                girlNamesSearch = SearchName(girlName, girlNames);
                searchResult = GetResults(girlName, girlNamesSearch);
            }
            // Else update the result with string data to notify the user to enter boy and or girl names
            else
            {
                searchResult = "Please enter a boy name or girl name or both to start the search.";
            }

            // Display the message to user
            MessageBox.Show(searchResult);

            // Clear both text boxes
            ClearTextBoxes();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exit the form
            this.Close();
        }
    }
}
