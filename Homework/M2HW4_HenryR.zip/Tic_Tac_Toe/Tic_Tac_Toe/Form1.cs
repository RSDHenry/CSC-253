﻿/**
* 29 September 2018
* CSC 253
* Rashad Henry
* Tic Tac Toe simulation app that uses 2D arrays to simulate the 
* game board in memory and randomly generates a new board outcome after
* button click
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Tic_Tac_Toe
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        // Create a 2D array for int type for board 3 x 3
        int[,] board = new int[3, 3];
        // Create the same 2D array as a string type
        string[,] choice = new string[3, 3];

        private void Tic_Tac_Toe()
        {
            InitializeComponent();
           
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Load event and create a random object from the Random class
            Random rand = new Random();

            // For loops to hold random numbers in a index of a array
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    // Use the min and max values to generate random numbers
                    board[i, j] = rand.Next(0, 2);

                    // Hold the letter O (capital O - not zero) for zero and X for 1 to choice array
                    if (board[i, j] == 0)
                        choice[i, j] = "O";
                    else
                        choice[i, j] = "X";
                }
            }

            // Display the indexes of choice array in the board labels
            gameLbl1.Text = choice[0, 0];
            gameLbl2.Text = choice[0, 1];
            gameLbl3.Text = choice[0, 2];
            gameLbl4.Text = choice[1, 0];
            gameLbl5.Text = choice[1, 1];
            gameLbl6.Text = choice[1, 2];
            gameLbl7.Text = choice[2, 0];
            gameLbl8.Text = choice[2, 1];
            gameLbl9.Text = choice[2, 2];

            // Check for winners on the X and Y horizontal axis
            if ((gameLbl1.Text == "X") && (gameLbl2.Text == "X") && (gameLbl3.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl1.Text == "O") && (gameLbl2.Text == "O") && (gameLbl3.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";
            else if ((gameLbl4.Text == "X") && (gameLbl5.Text == "X") && (gameLbl6.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl4.Text == "O") && (gameLbl5.Text == "O") && (gameLbl6.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";
            else if ((gameLbl7.Text == "X") && (gameLbl8.Text == "X") && (gameLbl9.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl7.Text == "O") && (gameLbl8.Text == "O") && (gameLbl9.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";

            // Check for winners on the X and Y vertical axis
            else if ((gameLbl1.Text == "X") && (gameLbl4.Text == "X") && (gameLbl7.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl1.Text == "O") && (gameLbl4.Text == "O") && (gameLbl7.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";
            else if ((gameLbl2.Text == "X") && (gameLbl5.Text == "X") && (gameLbl8.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl2.Text == "O") && (gameLbl5.Text == "O") && (gameLbl8.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";
            else if ((gameLbl3.Text == "X") && (gameLbl6.Text == "X") && (gameLbl9.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl3.Text == "O") && (gameLbl6.Text == "O") && (gameLbl9.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";

            // Check for winners on the X and Y axis diagonally
            else if ((gameLbl1.Text == "X") && (gameLbl5.Text == "X") && (gameLbl9.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl1.Text == "O") && (gameLbl5.Text == "O") && (gameLbl9.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";
            else if ((gameLbl3.Text == "X") && (gameLbl5.Text == "X") && (gameLbl7.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl3.Text == "O") && (gameLbl5.Text == "O") && (gameLbl7.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";

            // In the instance of a tie check for a tie on the horizontal axis
            else if ((gameLbl1.Text != gameLbl2.Text) && (gameLbl2.Text != gameLbl3.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";
            else if ((gameLbl2.Text != gameLbl3.Text) && (gameLbl3.Text != gameLbl4.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";
            else if ((gameLbl5.Text != gameLbl6.Text) && (gameLbl6.Text != gameLbl7.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";

            // In the instance of a tie check for a tie on the vertical axis
            else if ((gameLbl1.Text != gameLbl4.Text) && (gameLbl4.Text != gameLbl7.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";
            else if ((gameLbl2.Text != gameLbl5.Text) && (gameLbl5.Text != gameLbl8.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";
            else if ((gameLbl3.Text != gameLbl6.Text) && (gameLbl6.Text != gameLbl9.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";

            // In the instance of a tie check for a tie diagonally
            else if ((gameLbl1.Text != gameLbl5.Text) && (gameLbl5.Text != gameLbl9.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";
            else if ((gameLbl3.Text != gameLbl5.Text) && (gameLbl5.Text != gameLbl7.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";
        }

        private void playGameButton_Click(object sender, EventArgs e)
        {
            // Create a new random object from the Random class
            Random rand = new Random();

            // For loop to hold random numbers in a index array
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    // Use min and max values to generate random numbers
                    board[i, j] = rand.Next(0, 2);

                    // Hold the letter O (capital O - not zero) and X for 1 in choice array
                    if (board[i, j] == 0)
                        choice[i, j] = "O";
                    else
                        choice[i, j] = "X";
                }
            }

            // Display the indexes of choice
            gameLbl1.Text = choice[0, 0];
            gameLbl2.Text = choice[0, 1];
            gameLbl3.Text = choice[0, 2];
            gameLbl4.Text = choice[1, 0];
            gameLbl5.Text = choice[1, 1];
            gameLbl6.Text = choice[1, 2];
            gameLbl7.Text = choice[2, 0];
            gameLbl8.Text = choice[2, 1];
            gameLbl9.Text = choice[2, 2];

            // Check for winners on the X and Y horizontal axis
            if ((gameLbl1.Text == "X") && (gameLbl2.Text == "X") && (gameLbl3.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl1.Text == "O") && (gameLbl2.Text == "O") && (gameLbl3.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";
            else if ((gameLbl4.Text == "X") && (gameLbl5.Text == "X") && (gameLbl6.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl4.Text == "O") && (gameLbl5.Text == "O") && (gameLbl6.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";
            else if ((gameLbl7.Text == "X") && (gameLbl8.Text == "X") && (gameLbl9.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl7.Text == "O") && (gameLbl8.Text == "O") && (gameLbl9.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";

            // Check for winners on the X and Y vertical axis
            else if ((gameLbl1.Text == "X") && (gameLbl4.Text == "X") && (gameLbl7.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl1.Text == "O") && (gameLbl4.Text == "O") && (gameLbl7.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";
            else if ((gameLbl2.Text == "X") && (gameLbl5.Text == "X") && (gameLbl8.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl2.Text == "O") && (gameLbl5.Text == "O") && (gameLbl8.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";
            else if ((gameLbl3.Text == "X") && (gameLbl6.Text == "X") && (gameLbl9.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl3.Text == "O") && (gameLbl6.Text == "O") && (gameLbl9.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";

            // Check for winners on the X and Y axis diagonally
            else if ((gameLbl1.Text == "X") && (gameLbl5.Text == "X") && (gameLbl9.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl1.Text == "O") && (gameLbl5.Text == "O") && (gameLbl9.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";
            else if ((gameLbl3.Text == "X") && (gameLbl5.Text == "X") && (gameLbl7.Text == "X"))
                gameResultsTxtBox.Text = "X Wins!";
            else if ((gameLbl3.Text == "O") && (gameLbl5.Text == "O") && (gameLbl7.Text == "O"))
                gameResultsTxtBox.Text = "Y Wins!";

            // In the instance of a tie check for a tie on the horizontal axis
            else if ((gameLbl1.Text != gameLbl2.Text) && (gameLbl2.Text != gameLbl3.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";
            else if ((gameLbl2.Text != gameLbl3.Text) && (gameLbl3.Text != gameLbl4.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";
            else if ((gameLbl5.Text != gameLbl6.Text) && (gameLbl6.Text != gameLbl7.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";

            // In the instance of a tie check for a tie on the vertical axis
            else if ((gameLbl1.Text != gameLbl4.Text) && (gameLbl4.Text != gameLbl7.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";
            else if ((gameLbl2.Text != gameLbl5.Text) && (gameLbl5.Text != gameLbl8.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";
            else if ((gameLbl3.Text != gameLbl6.Text) && (gameLbl6.Text != gameLbl9.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";

            // In the instance of a tie check for a tie diagonally
            else if ((gameLbl1.Text != gameLbl5.Text) && (gameLbl5.Text != gameLbl9.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";
            else if ((gameLbl3.Text != gameLbl5.Text) && (gameLbl5.Text != gameLbl7.Text))
                gameResultsTxtBox.Text = "Game ends in a tie!";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }
    }     
}