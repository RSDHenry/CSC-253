﻿namespace Tic_Tac_Toe
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gameLbl1 = new System.Windows.Forms.Label();
            this.gameLbl2 = new System.Windows.Forms.Label();
            this.gameLbl3 = new System.Windows.Forms.Label();
            this.gameLbl4 = new System.Windows.Forms.Label();
            this.gameLbl5 = new System.Windows.Forms.Label();
            this.gameLbl6 = new System.Windows.Forms.Label();
            this.gameLbl7 = new System.Windows.Forms.Label();
            this.gameLbl8 = new System.Windows.Forms.Label();
            this.gameLbl9 = new System.Windows.Forms.Label();
            this.gameResultsTxtBox = new System.Windows.Forms.TextBox();
            this.playGameButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // gameLbl1
            // 
            this.gameLbl1.AutoSize = true;
            this.gameLbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameLbl1.Location = new System.Drawing.Point(59, 43);
            this.gameLbl1.Name = "gameLbl1";
            this.gameLbl1.Size = new System.Drawing.Size(56, 55);
            this.gameLbl1.TabIndex = 0;
            this.gameLbl1.Text = "X";
            // 
            // gameLbl2
            // 
            this.gameLbl2.AutoSize = true;
            this.gameLbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameLbl2.Location = new System.Drawing.Point(160, 43);
            this.gameLbl2.Name = "gameLbl2";
            this.gameLbl2.Size = new System.Drawing.Size(56, 55);
            this.gameLbl2.TabIndex = 1;
            this.gameLbl2.Text = "X";
            // 
            // gameLbl3
            // 
            this.gameLbl3.AutoSize = true;
            this.gameLbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameLbl3.Location = new System.Drawing.Point(256, 43);
            this.gameLbl3.Name = "gameLbl3";
            this.gameLbl3.Size = new System.Drawing.Size(56, 55);
            this.gameLbl3.TabIndex = 2;
            this.gameLbl3.Text = "X";
            // 
            // gameLbl4
            // 
            this.gameLbl4.AutoSize = true;
            this.gameLbl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameLbl4.Location = new System.Drawing.Point(59, 136);
            this.gameLbl4.Name = "gameLbl4";
            this.gameLbl4.Size = new System.Drawing.Size(56, 55);
            this.gameLbl4.TabIndex = 3;
            this.gameLbl4.Text = "X";
            // 
            // gameLbl5
            // 
            this.gameLbl5.AutoSize = true;
            this.gameLbl5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameLbl5.Location = new System.Drawing.Point(160, 136);
            this.gameLbl5.Name = "gameLbl5";
            this.gameLbl5.Size = new System.Drawing.Size(56, 55);
            this.gameLbl5.TabIndex = 4;
            this.gameLbl5.Text = "X";
            // 
            // gameLbl6
            // 
            this.gameLbl6.AutoSize = true;
            this.gameLbl6.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameLbl6.Location = new System.Drawing.Point(256, 136);
            this.gameLbl6.Name = "gameLbl6";
            this.gameLbl6.Size = new System.Drawing.Size(56, 55);
            this.gameLbl6.TabIndex = 5;
            this.gameLbl6.Text = "X";
            // 
            // gameLbl7
            // 
            this.gameLbl7.AutoSize = true;
            this.gameLbl7.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameLbl7.Location = new System.Drawing.Point(59, 227);
            this.gameLbl7.Name = "gameLbl7";
            this.gameLbl7.Size = new System.Drawing.Size(56, 55);
            this.gameLbl7.TabIndex = 6;
            this.gameLbl7.Text = "X";
            // 
            // gameLbl8
            // 
            this.gameLbl8.AutoSize = true;
            this.gameLbl8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameLbl8.Location = new System.Drawing.Point(160, 227);
            this.gameLbl8.Name = "gameLbl8";
            this.gameLbl8.Size = new System.Drawing.Size(56, 55);
            this.gameLbl8.TabIndex = 7;
            this.gameLbl8.Text = "X";
            // 
            // gameLbl9
            // 
            this.gameLbl9.AutoSize = true;
            this.gameLbl9.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameLbl9.Location = new System.Drawing.Point(256, 227);
            this.gameLbl9.Name = "gameLbl9";
            this.gameLbl9.Size = new System.Drawing.Size(56, 55);
            this.gameLbl9.TabIndex = 8;
            this.gameLbl9.Text = "X";
            // 
            // gameResultsTxtBox
            // 
            this.gameResultsTxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameResultsTxtBox.Location = new System.Drawing.Point(69, 315);
            this.gameResultsTxtBox.Name = "gameResultsTxtBox";
            this.gameResultsTxtBox.Size = new System.Drawing.Size(243, 22);
            this.gameResultsTxtBox.TabIndex = 9;
            // 
            // playGameButton
            // 
            this.playGameButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playGameButton.Location = new System.Drawing.Point(69, 356);
            this.playGameButton.Name = "playGameButton";
            this.playGameButton.Size = new System.Drawing.Size(90, 31);
            this.playGameButton.TabIndex = 10;
            this.playGameButton.Text = "Play";
            this.playGameButton.UseVisualStyleBackColor = true;
            this.playGameButton.Click += new System.EventHandler(this.playGameButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(222, 356);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(90, 31);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(373, 399);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.playGameButton);
            this.Controls.Add(this.gameResultsTxtBox);
            this.Controls.Add(this.gameLbl9);
            this.Controls.Add(this.gameLbl8);
            this.Controls.Add(this.gameLbl7);
            this.Controls.Add(this.gameLbl6);
            this.Controls.Add(this.gameLbl5);
            this.Controls.Add(this.gameLbl4);
            this.Controls.Add(this.gameLbl3);
            this.Controls.Add(this.gameLbl2);
            this.Controls.Add(this.gameLbl1);
            this.Name = "MainForm";
            this.Text = "Tic-Tac-Toe!";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label gameLbl1;
        private System.Windows.Forms.Label gameLbl2;
        private System.Windows.Forms.Label gameLbl3;
        private System.Windows.Forms.Label gameLbl4;
        private System.Windows.Forms.Label gameLbl5;
        private System.Windows.Forms.Label gameLbl6;
        private System.Windows.Forms.Label gameLbl7;
        private System.Windows.Forms.Label gameLbl8;
        private System.Windows.Forms.Label gameLbl9;
        private System.Windows.Forms.TextBox gameResultsTxtBox;
        private System.Windows.Forms.Button playGameButton;
        private System.Windows.Forms.Button exitButton;
    }
}

