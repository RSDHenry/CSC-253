﻿/**
* 18 October 2018
* CSC 253
* Rashad Henry
* Program form with two arrays for various string characters (letters, digits, punctuations)
* to take a user entered string and convert the string to a morse code output string
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MorseCodeConverter
{
    public partial class MainForm : Form
    {
        // Arrary for the English alphabet, numbers 1-9, and common punctuation marks
        private char[] chars = { ' ',',','.','?','0','1','2','3','4','5',
            '6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L',
            'M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z' };

        // Array for morse codes
        private string[] codes = { " ", "--..--", ".-.-.-","..--..","-----",".----",
            "..---","...--","....-",".....","-....","--...","---..","----.",".-","-...",
            "-.-.","-..",".","..-.","--.","....","..",".---","-.-",".-..","--","-.",
            "---",".--.","--.-",".-.","...","-","..-","...-",".--","-..-","-.--","--.." };

        public MainForm()
        {
            InitializeComponent();
        }

        private void ConvertButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Acquire the user entered string from the text box
                string englishTextString = stringTextBox.Text;
                string result = "";
                int count = 0;

                // For loop for all characters in the user entered string
                for (int i = 0; i < englishTextString.Length; i++)
                {
                    // Repeat the for loop for all the characters in the chars array
                    for (int j = 0; j < chars.Length; j++)
                    {
                        // Acquire a letter from the user entered text string
                        char letter = char.ToUpper(englishTextString[i]);
                        // Verification to see if the string letter is in the char array
                        if (letter == chars[j])
                        {
                            // Append to the results
                            result = result + codes[j];
                            // A count for the number of valid letters
                            count++;
                        }
                    }
                }
                // Verification for number of valid letters equals number of characters in the user entered text string
                if (count == englishTextString.Length)
                {
                    displayMorseCodeLabel.Text = result;

                }
                else displayMorseCodeLabel.Text = "Invalid text string was entered";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void ExitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }

        private void ClearFormButton_Click(object sender, EventArgs e)
        {
            // Clear the form to allow new entry
            stringTextBox.Text = "";
            displayMorseCodeLabel.Text = "";
        }
    }
}