﻿namespace Sum_Of_Numbers_In_A_String
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.instructionLbl = new System.Windows.Forms.Label();
            this.sumOfNumsLbl = new System.Windows.Forms.Label();
            this.numStringTxtBox = new System.Windows.Forms.TextBox();
            this.sumOfNumsTxtBox = new System.Windows.Forms.TextBox();
            this.calculateSumBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // instructionLbl
            // 
            this.instructionLbl.AutoSize = true;
            this.instructionLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionLbl.Location = new System.Drawing.Point(13, 30);
            this.instructionLbl.Name = "instructionLbl";
            this.instructionLbl.Size = new System.Drawing.Size(315, 15);
            this.instructionLbl.TabIndex = 0;
            this.instructionLbl.Text = "Enter a String of Numbers: (Include commas: ex: 1,2,3,4)\r\n";
            // 
            // sumOfNumsLbl
            // 
            this.sumOfNumsLbl.AutoSize = true;
            this.sumOfNumsLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sumOfNumsLbl.Location = new System.Drawing.Point(13, 88);
            this.sumOfNumsLbl.Name = "sumOfNumsLbl";
            this.sumOfNumsLbl.Size = new System.Drawing.Size(215, 15);
            this.sumOfNumsLbl.TabIndex = 1;
            this.sumOfNumsLbl.Text = "The Sum of the Numbers in the String:";
            // 
            // numStringTxtBox
            // 
            this.numStringTxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numStringTxtBox.Location = new System.Drawing.Point(334, 30);
            this.numStringTxtBox.Name = "numStringTxtBox";
            this.numStringTxtBox.Size = new System.Drawing.Size(250, 21);
            this.numStringTxtBox.TabIndex = 2;
            // 
            // sumOfNumsTxtBox
            // 
            this.sumOfNumsTxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sumOfNumsTxtBox.Location = new System.Drawing.Point(334, 82);
            this.sumOfNumsTxtBox.Name = "sumOfNumsTxtBox";
            this.sumOfNumsTxtBox.Size = new System.Drawing.Size(250, 21);
            this.sumOfNumsTxtBox.TabIndex = 3;
            // 
            // calculateSumBtn
            // 
            this.calculateSumBtn.Location = new System.Drawing.Point(154, 162);
            this.calculateSumBtn.Name = "calculateSumBtn";
            this.calculateSumBtn.Size = new System.Drawing.Size(103, 36);
            this.calculateSumBtn.TabIndex = 4;
            this.calculateSumBtn.Text = "Display Sum of String";
            this.calculateSumBtn.UseVisualStyleBackColor = true;
            this.calculateSumBtn.Click += new System.EventHandler(this.calculateSumBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.Location = new System.Drawing.Point(263, 162);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(103, 36);
            this.clearBtn.TabIndex = 5;
            this.clearBtn.Text = "Clear Form";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(372, 162);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(103, 36);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit ";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(596, 210);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.calculateSumBtn);
            this.Controls.Add(this.sumOfNumsTxtBox);
            this.Controls.Add(this.numStringTxtBox);
            this.Controls.Add(this.sumOfNumsLbl);
            this.Controls.Add(this.instructionLbl);
            this.Name = "MainForm";
            this.Text = "Sum of Numbers In A String";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionLbl;
        private System.Windows.Forms.Label sumOfNumsLbl;
        private System.Windows.Forms.TextBox numStringTxtBox;
        private System.Windows.Forms.TextBox sumOfNumsTxtBox;
        private System.Windows.Forms.Button calculateSumBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button exitButton;
    }
}

