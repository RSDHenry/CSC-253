﻿/**
* 10 October 2018
* CSC 253
* Rashad Henry
* Application gets user input as a string and converts 
* it to an int and uses the trim method  to remove whitespaces 
* to accurately calculate the numbers provided to display the 
* total of the numbers back to the user.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sum_Of_Numbers_In_A_String
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void calculateSumBtn_Click(object sender, EventArgs e)
        {
            // Assign the user input to a str variable and trim the white space from the input
            string str = numStringTxtBox.Text.Trim();

            // Declare a variable to hold the sum
            int sum = 0;

            // Creation of the char array containing the comma 
            char[] delimiter = {','};

            // Trim the white space from the string
            str = str.Trim();

            // display an error message if not string was entered at all
            if (str.Trim() == "")
            {
                MessageBox.Show("Please enter a string of numbers");

                return;
            }

            // Tokenize the string and gather token from the string
            string[] tokens = str.Split(delimiter);

            // Check to see if each token is numeric
            foreach (string st in tokens)
            {
                // Checking for numeric
                if (isNumeric(st))
                {
                    // If isNumeric is numeric then add to the sum variable
                    sum = sum + Convert.ToInt32(st);
                }
            }

            // Assign the calculated sum of numbers in the string to the sumOfNumsTxtBox
            sumOfNumsTxtBox.Text = sum.ToString();
        }

        // Method to check if the provided string is numeric
        private bool isNumeric (string st)
        {
            bool numeric = true;

            // Check to verify if each character in the string is numeric
            foreach (char ch in st)
            {
                char.IsDigit(ch);
                    if (!char.IsDigit(ch))
                {
                    numeric = false;
                    break;
                }
            }
            // Return numeric
            return numeric;
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            // Clear the form
            numStringTxtBox.Text = "";
            sumOfNumsTxtBox.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exit the form.
            this.Close();
        }
    }
}