﻿namespace Book_Club_Points
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bookLabel = new System.Windows.Forms.Label();
            this.awardedPointsLabel = new System.Windows.Forms.Label();
            this.displayResultLabel = new System.Windows.Forms.Label();
            this.calculatePointsButton = new System.Windows.Forms.Button();
            this.numOfBooksTextBox = new System.Windows.Forms.TextBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bookLabel
            // 
            this.bookLabel.AutoSize = true;
            this.bookLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookLabel.Location = new System.Drawing.Point(36, 43);
            this.bookLabel.Name = "bookLabel";
            this.bookLabel.Size = new System.Drawing.Size(320, 16);
            this.bookLabel.TabIndex = 0;
            this.bookLabel.Text = "Enter the number of books you purchased this month:";
            // 
            // awardedPointsLabel
            // 
            this.awardedPointsLabel.AutoSize = true;
            this.awardedPointsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.awardedPointsLabel.Location = new System.Drawing.Point(188, 108);
            this.awardedPointsLabel.Name = "awardedPointsLabel";
            this.awardedPointsLabel.Size = new System.Drawing.Size(168, 16);
            this.awardedPointsLabel.TabIndex = 1;
            this.awardedPointsLabel.Text = "Number of points awarded:";
            // 
            // displayResultLabel
            // 
            this.displayResultLabel.AutoSize = true;
            this.displayResultLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayResultLabel.Location = new System.Drawing.Point(362, 108);
            this.displayResultLabel.Name = "displayResultLabel";
            this.displayResultLabel.Size = new System.Drawing.Size(15, 16);
            this.displayResultLabel.TabIndex = 2;
            this.displayResultLabel.Text = "0";
            // 
            // calculatePointsButton
            // 
            this.calculatePointsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculatePointsButton.Location = new System.Drawing.Point(39, 95);
            this.calculatePointsButton.Name = "calculatePointsButton";
            this.calculatePointsButton.Size = new System.Drawing.Size(122, 42);
            this.calculatePointsButton.TabIndex = 3;
            this.calculatePointsButton.Text = "Calculate Points";
            this.calculatePointsButton.UseVisualStyleBackColor = true;
            this.calculatePointsButton.Click += new System.EventHandler(this.calculatePointsButton_Click);
            // 
            // numOfBooksTextBox
            // 
            this.numOfBooksTextBox.Location = new System.Drawing.Point(362, 43);
            this.numOfBooksTextBox.Name = "numOfBooksTextBox";
            this.numOfBooksTextBox.Size = new System.Drawing.Size(67, 20);
            this.numOfBooksTextBox.TabIndex = 4;
            // 
            // clearButton
            // 
            this.clearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Location = new System.Drawing.Point(39, 158);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(122, 42);
            this.clearButton.TabIndex = 5;
            this.clearButton.Text = "Reset";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(191, 158);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(122, 42);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(461, 216);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.numOfBooksTextBox);
            this.Controls.Add(this.calculatePointsButton);
            this.Controls.Add(this.displayResultLabel);
            this.Controls.Add(this.awardedPointsLabel);
            this.Controls.Add(this.bookLabel);
            this.Name = "MainForm";
            this.Text = "Book Club Points";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label bookLabel;
        private System.Windows.Forms.Label awardedPointsLabel;
        private System.Windows.Forms.Label displayResultLabel;
        private System.Windows.Forms.Button calculatePointsButton;
        private System.Windows.Forms.TextBox numOfBooksTextBox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

