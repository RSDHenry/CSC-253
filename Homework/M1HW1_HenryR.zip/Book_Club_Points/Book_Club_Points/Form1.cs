﻿/**
* 31 Aug 2018
* CSC 253
* Rashad Henry
* A form calculator that takes user input and 
* calculates the number of points earned from 
* buying books
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Club_Points
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void calculatePointsButton_Click(object sender, EventArgs e)
        {
            try
            {


                // Variable declarations
                int numOfBooks = 0;
                int pointsEarned = 0;

                // Accept number of books input string from the user and convert to an int
                numOfBooks = Convert.ToInt32(numOfBooksTextBox.Text);

                // If number of books purchased is 0 then set the points earned to 0
                if (numOfBooks == 0)
                    pointsEarned = 0;
                else if (numOfBooks == 1)   // Else if number of books purchased is 1 then set the points earned to 5
                    pointsEarned = 5;
                else if (numOfBooks == 2)   // Else if number of books purchased is 2 then set the points earned to 15
                    pointsEarned = 15;
                else if (numOfBooks == 3)   // Else if number of books purchased is 3 then set the points earned to 30
                    pointsEarned = 30;
                else if (numOfBooks > 4)   // Else if number of books purchased is 4 or more then set the points earned to 60
                    pointsEarned = 60;

                // Display the awarded points to the user in the displayResultLabel
                displayResultLabel.Text = pointsEarned.ToString();
            }
            catch
            {
                // Display an error message
                MessageBox.Show("Invalid data was entered. Make sure you are entering a positive number.");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears the form of any data
            numOfBooksTextBox.Text = "";
            displayResultLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the form
            this.Close();
        }
    }
}
