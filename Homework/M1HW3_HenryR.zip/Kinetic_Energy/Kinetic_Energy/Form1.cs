﻿/**
* 5 September 2018
* CSC 253
* Rashad Henry
* Program accepts user input for mass and velocity
* and calculates it then displays the result in 
* kinetic energy (joules)
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kinetic_Energy
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void calculateBtn_Click(object sender, EventArgs e)
        {
            try
            {

                // Variable declaration
                double mass;
                double velocity;
                double kinEnergy;

                // Formula for calculating kinetic energy is KE = 1/2 m(mass) * v(velocity) ^2 

                // Accept the object's mass from the massTextBox
                mass = double.Parse(massTextBox.Text);

                // Accept the object's velocity from the velocityTextBox
                velocity = double.Parse(velocityTextBox.Text);

                // Call the KineticEneMethod to get the kinetic energy
                kinEnergy = KineticEnergy(mass, velocity);

                // Display the calculated kinetic energy to the user. Kinetic Energy is displayed in Joules.
                displayKinEnergyLbl.Text = kinEnergy.ToString("F0");    // Using F0 formatting to remove the decimal and everything after
            }
            catch
            {
                // Display an error message
                MessageBox.Show("Invalid data or no data at all was entered. Please try again.");
            }
        }
            
        private void resetBtn_Click(object sender, EventArgs e)
        {
            // Clear the form
            massTextBox.Text = "";
            velocityTextBox.Text = "";
            displayKinEnergyLbl.Text = "";
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            // Exit the form
            this.Close();
        }

        // KineticEnergy Method
        private double KineticEnergy(double mass, double velocity)
        {
            // Return value method to return the calculation of the values given
            return (0.5 * mass * velocity * velocity);
        }
    }
}