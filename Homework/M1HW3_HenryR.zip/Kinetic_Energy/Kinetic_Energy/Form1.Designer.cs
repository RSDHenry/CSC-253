﻿namespace Kinetic_Energy
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.applicationTitleLbl = new System.Windows.Forms.Label();
            this.massLbl = new System.Windows.Forms.Label();
            this.massTextBox = new System.Windows.Forms.TextBox();
            this.velocityLbl = new System.Windows.Forms.Label();
            this.velocityTextBox = new System.Windows.Forms.TextBox();
            this.calculateBtn = new System.Windows.Forms.Button();
            this.kineticEgyLbl = new System.Windows.Forms.Label();
            this.displayKinEnergyLbl = new System.Windows.Forms.Label();
            this.resetBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // applicationTitleLbl
            // 
            this.applicationTitleLbl.AutoSize = true;
            this.applicationTitleLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.applicationTitleLbl.Location = new System.Drawing.Point(99, 48);
            this.applicationTitleLbl.Name = "applicationTitleLbl";
            this.applicationTitleLbl.Size = new System.Drawing.Size(181, 16);
            this.applicationTitleLbl.TabIndex = 0;
            this.applicationTitleLbl.Text = "Kinetic Energy Calculator";
            // 
            // massLbl
            // 
            this.massLbl.AutoSize = true;
            this.massLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.massLbl.Location = new System.Drawing.Point(47, 103);
            this.massLbl.Name = "massLbl";
            this.massLbl.Size = new System.Drawing.Size(97, 16);
            this.massLbl.TabIndex = 1;
            this.massLbl.Text = "Mass in kg (m):";
            // 
            // massTextBox
            // 
            this.massTextBox.Location = new System.Drawing.Point(168, 99);
            this.massTextBox.Name = "massTextBox";
            this.massTextBox.Size = new System.Drawing.Size(100, 20);
            this.massTextBox.TabIndex = 2;
            // 
            // velocityLbl
            // 
            this.velocityLbl.AutoSize = true;
            this.velocityLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.velocityLbl.Location = new System.Drawing.Point(47, 149);
            this.velocityLbl.Name = "velocityLbl";
            this.velocityLbl.Size = new System.Drawing.Size(115, 16);
            this.velocityLbl.TabIndex = 3;
            this.velocityLbl.Text = "Velocity in m/s (v):";
            // 
            // velocityTextBox
            // 
            this.velocityTextBox.Location = new System.Drawing.Point(168, 145);
            this.velocityTextBox.Name = "velocityTextBox";
            this.velocityTextBox.Size = new System.Drawing.Size(100, 20);
            this.velocityTextBox.TabIndex = 4;
            // 
            // calculateBtn
            // 
            this.calculateBtn.Location = new System.Drawing.Point(123, 201);
            this.calculateBtn.Name = "calculateBtn";
            this.calculateBtn.Size = new System.Drawing.Size(112, 47);
            this.calculateBtn.TabIndex = 5;
            this.calculateBtn.Text = "Calculate to Kinetic Energy";
            this.calculateBtn.UseVisualStyleBackColor = true;
            this.calculateBtn.Click += new System.EventHandler(this.calculateBtn_Click);
            // 
            // kineticEgyLbl
            // 
            this.kineticEgyLbl.AutoSize = true;
            this.kineticEgyLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kineticEgyLbl.Location = new System.Drawing.Point(47, 289);
            this.kineticEgyLbl.Name = "kineticEgyLbl";
            this.kineticEgyLbl.Size = new System.Drawing.Size(113, 16);
            this.kineticEgyLbl.TabIndex = 6;
            this.kineticEgyLbl.Text = "Kinetic Energy (j): ";
            // 
            // displayKinEnergyLbl
            // 
            this.displayKinEnergyLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.displayKinEnergyLbl.Location = new System.Drawing.Point(168, 289);
            this.displayKinEnergyLbl.Name = "displayKinEnergyLbl";
            this.displayKinEnergyLbl.Size = new System.Drawing.Size(100, 23);
            this.displayKinEnergyLbl.TabIndex = 7;
            // 
            // resetBtn
            // 
            this.resetBtn.Location = new System.Drawing.Point(65, 338);
            this.resetBtn.Name = "resetBtn";
            this.resetBtn.Size = new System.Drawing.Size(112, 47);
            this.resetBtn.TabIndex = 8;
            this.resetBtn.Text = "Reset Form";
            this.resetBtn.UseVisualStyleBackColor = true;
            this.resetBtn.Click += new System.EventHandler(this.resetBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(183, 338);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(112, 47);
            this.exitBtn.TabIndex = 9;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(358, 397);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.resetBtn);
            this.Controls.Add(this.displayKinEnergyLbl);
            this.Controls.Add(this.kineticEgyLbl);
            this.Controls.Add(this.calculateBtn);
            this.Controls.Add(this.velocityTextBox);
            this.Controls.Add(this.velocityLbl);
            this.Controls.Add(this.massTextBox);
            this.Controls.Add(this.massLbl);
            this.Controls.Add(this.applicationTitleLbl);
            this.Name = "MainForm";
            this.Text = "Kinetic Energy Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label applicationTitleLbl;
        private System.Windows.Forms.Label massLbl;
        private System.Windows.Forms.TextBox massTextBox;
        private System.Windows.Forms.Label velocityLbl;
        private System.Windows.Forms.TextBox velocityTextBox;
        private System.Windows.Forms.Button calculateBtn;
        private System.Windows.Forms.Label kineticEgyLbl;
        private System.Windows.Forms.Label displayKinEnergyLbl;
        private System.Windows.Forms.Button resetBtn;
        private System.Windows.Forms.Button exitBtn;
    }
}

