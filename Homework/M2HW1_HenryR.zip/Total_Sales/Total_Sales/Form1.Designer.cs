﻿namespace Total_Sales
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.totalSalesListBox = new System.Windows.Forms.ListBox();
            this.totalLabel = new System.Windows.Forms.Label();
            this.displayTotalTxtBox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // totalSalesListBox
            // 
            this.totalSalesListBox.FormattingEnabled = true;
            this.totalSalesListBox.Location = new System.Drawing.Point(17, 18);
            this.totalSalesListBox.Name = "totalSalesListBox";
            this.totalSalesListBox.Size = new System.Drawing.Size(340, 199);
            this.totalSalesListBox.TabIndex = 0;
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalLabel.Location = new System.Drawing.Point(14, 238);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(47, 15);
            this.totalLabel.TabIndex = 1;
            this.totalLabel.Text = "Total: ";
            // 
            // displayTotalTxtBox
            // 
            this.displayTotalTxtBox.Location = new System.Drawing.Point(57, 238);
            this.displayTotalTxtBox.Name = "displayTotalTxtBox";
            this.displayTotalTxtBox.Size = new System.Drawing.Size(100, 20);
            this.displayTotalTxtBox.TabIndex = 2;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(303, 274);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(393, 309);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.displayTotalTxtBox);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.totalSalesListBox);
            this.Name = "MainForm";
            this.Text = "Total Sales";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox totalSalesListBox;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.TextBox displayTotalTxtBox;
        private System.Windows.Forms.Button exitButton;
    }
}

