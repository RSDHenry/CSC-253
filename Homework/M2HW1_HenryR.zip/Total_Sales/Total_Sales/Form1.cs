﻿/**
* 29 September 2018
* CSC 253
* Rashad Henry
* Using an array and StreamReader object to read a text file and
* display the number of sale items and total sales amount
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Total_Sales
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {

                // Array to hold the sale amounts in decimal format
                decimal[] sales = new decimal[7];

                // Counter variable to iterate
                int count = 0;

                // Variable total to hold the final sales total
                decimal total = 0;

                // Create a new StreamReader object to read a sales.txt
                StreamReader inputFile;

                // Open the Sales.txt file and read to the end of the file
                inputFile = File.OpenText("Sales.txt");
                while (!inputFile.EndOfStream && count < sales.Length)
                {
                    // Convert the string text to a decimal
                    sales[count] = decimal.Parse(inputFile.ReadLine());
                    count++;
                }

                // Close the file
                inputFile.Close();

                // Add the sale items to the listBox
                totalSalesListBox.Items.Add("This file contains " + count + " items.");

                // For loop to increment and add the number of sale items to the listBox
                for (int index = 0; index < count; index++)
                {
                    // Add each sale item to the listBox
                    totalSalesListBox.Items.Add(sales[index]);
                    total += sales[index];
                }

                // Display the calculated total in dollar currency to the text box
                displayTotalTxtBox.Text = total.ToString("c");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }
    }
}
