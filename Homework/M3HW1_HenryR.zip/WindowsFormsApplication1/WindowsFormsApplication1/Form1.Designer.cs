﻿namespace Word_Counter
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.instructionLbl = new System.Windows.Forms.Label();
            this.wordCountTxtBox = new System.Windows.Forms.TextBox();
            this.displayWordCountBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.clearFormBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // instructionLbl
            // 
            this.instructionLbl.AutoSize = true;
            this.instructionLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionLbl.Location = new System.Drawing.Point(13, 31);
            this.instructionLbl.Name = "instructionLbl";
            this.instructionLbl.Size = new System.Drawing.Size(343, 16);
            this.instructionLbl.TabIndex = 0;
            this.instructionLbl.Text = "Please Enter A String To Display The Number Of Words:";
            // 
            // wordCountTxtBox
            // 
            this.wordCountTxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wordCountTxtBox.Location = new System.Drawing.Point(16, 75);
            this.wordCountTxtBox.Name = "wordCountTxtBox";
            this.wordCountTxtBox.Size = new System.Drawing.Size(396, 22);
            this.wordCountTxtBox.TabIndex = 1;
            // 
            // displayWordCountBtn
            // 
            this.displayWordCountBtn.Location = new System.Drawing.Point(16, 137);
            this.displayWordCountBtn.Name = "displayWordCountBtn";
            this.displayWordCountBtn.Size = new System.Drawing.Size(90, 37);
            this.displayWordCountBtn.TabIndex = 2;
            this.displayWordCountBtn.Text = "Display Word Count";
            this.displayWordCountBtn.UseVisualStyleBackColor = true;
            this.displayWordCountBtn.Click += new System.EventHandler(this.displayWordCountBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(322, 137);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(90, 37);
            this.exitBtn.TabIndex = 3;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // clearFormBtn
            // 
            this.clearFormBtn.Location = new System.Drawing.Point(167, 137);
            this.clearFormBtn.Name = "clearFormBtn";
            this.clearFormBtn.Size = new System.Drawing.Size(90, 37);
            this.clearFormBtn.TabIndex = 4;
            this.clearFormBtn.Text = "Clear Form";
            this.clearFormBtn.UseVisualStyleBackColor = true;
            this.clearFormBtn.Click += new System.EventHandler(this.clearFormBtn_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 199);
            this.Controls.Add(this.clearFormBtn);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.displayWordCountBtn);
            this.Controls.Add(this.wordCountTxtBox);
            this.Controls.Add(this.instructionLbl);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionLbl;
        private System.Windows.Forms.TextBox wordCountTxtBox;
        private System.Windows.Forms.Button displayWordCountBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Button clearFormBtn;
    }
}

