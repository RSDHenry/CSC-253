﻿/**
* 9 Octoober 2018
* CSC 253
* Rashad Henry
* Application that uses a method to accept a string input
* as an argument and returns the number of words the string
* contains.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Word_Counter
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void displayWordCountBtn_Click(object sender, EventArgs e)
        {
            // Variable to hold the entered string 
            string str = wordCountTxtBox.Text;

            // Trim method to trim the white spaces before and after the string
            if (str.Trim() == "")
            {
                // Display instructions to the user if no string was entered
                MessageBox.Show("Please enter a string to display the number of words");

                return;
            }

            // Call the method CountStringWords
            int numOfWords = CountStringWords(str);

            // Display the number of words in the string to the user
            MessageBox.Show("The number of words in the provided string is " + numOfWords.ToString());
        }

        private int CountStringWords(string str)
        {

            /** The method tokenizes the string using the white space as a delimiter when null is passed 
            as an argument to the split method.
            */

            // Variable declaration
            int countWords = 0;

            // Take the whitespace and the split the number of words based on the whitespace
            string[] strWords = str.Split(null);

            // Count the number of words in the provided string
            countWords = strWords.Length;

            return countWords;
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }

        private void clearFormBtn_Click(object sender, EventArgs e)
        {
            // Clear the data in the form
            wordCountTxtBox.Text = "";
        }
    }
}
